import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score

from cardio_library.preprocessing.transformer import CardioTransformer
from cardio_library.models.logistic_model import LogisticModel
from cardio_library.utils.save_load import save_model, save_transformer

# Деректерді оқу
data = pd.read_csv("cardio_train.csv", sep=";")

# Трансформер
transformer = CardioTransformer()

# Трансформерді үйрету
transformer.fit(data)

# Деректерді түрлендіру
X, y = transformer.transform(data)

# Мәліметті бөлу
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, stratify=y, random_state=42)

# Модель
model = LogisticModel()
model.fit(X_train, y_train)

# Болжам
y_pred = model.predict(X_test)
y_proba = model.predict_proba(X_test)

# Метрикалар
print("Бағалау нәтижелері:")
print("Accuracy:", accuracy_score(y_test, y_pred))
print("Precision:", precision_score(y_test, y_pred))
print("Recall:", recall_score(y_test, y_pred))
print("F1 Score:", f1_score(y_test, y_pred))
print("ROC AUC:", roc_auc_score(y_test, y_proba))

# Сақтау
save_model(model, "cardio_library/models/logistic_model.pkl")
save_transformer(transformer, "cardio_library/preprocessing/transformer.pkl")

print("Модель мен трансформер сәтті сақталды.")
