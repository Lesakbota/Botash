import joblib

# 🔹 Модельді сақтау
def save_model(model, path):
    joblib.dump(model, path)

# 🔹 Трансформаторды сақтау
def save_transformer(transformer, path):
    joblib.dump(transformer, path)

# 🔹 Модельді жүктеу
def load_model(path):
    return joblib.load(path)

# 🔹 Трансформаторды жүктеу
def load_transformer(path):
    return joblib.load(path)
