from sklearn.model_selection import GridSearchCV
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.base import BaseEstimator
from sklearn.metrics import make_scorer, f1_score

def perform_grid_search(model: BaseEstimator, X, y):
    # Модель түрін тексеру және сәйкес параметр торын таңдау
    if isinstance(model, RandomForestClassifier):
        param_grid = {
            'n_estimators': [50, 100],
            'max_depth': [5, 10, None],
            'min_samples_split': [2, 5],
        }
    elif isinstance(model, LogisticRegression):
        param_grid = {
            'C': [0.01, 0.1, 1.0, 10.0],
            'penalty': ['l2'],
            'solver': ['lbfgs'],
            'class_weight': ['balanced']
        }
    elif isinstance(model, DecisionTreeClassifier):
        param_grid = {
            'max_depth': [3, 5, 10],
            'min_samples_split': [2, 5, 10]
        }
    else:
        raise ValueError("Бұл модель үшін GridSearch қолдау көрсетілмейді.")

    grid_search = GridSearchCV(
        estimator=model,
        param_grid=param_grid,
        scoring=make_scorer(f1_score),
        cv=5,
        n_jobs=-1
    )
    grid_search.fit(X, y)
    return grid_search.best_params_, grid_search.best_score_
