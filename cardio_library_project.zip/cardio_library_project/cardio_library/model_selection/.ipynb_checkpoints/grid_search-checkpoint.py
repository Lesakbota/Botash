from sklearn.model_selection import GridSearchCV

def perform_grid_search(estimator, param_grid, X, y, cv=5, scoring='accuracy'):
    grid = GridSearchCV(estimator, param_grid, cv=cv, scoring=scoring)
    grid.fit(X, y)
    return grid.best_estimator_, grid.best_params_, grid.best_score_
