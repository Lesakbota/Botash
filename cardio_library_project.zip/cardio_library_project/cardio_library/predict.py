import pandas as pd
import numpy as np  # NumPy кітапханасын қосу
from models.random_forest_model import RandomForestModel  # RandomForest-ты қолдану
from preprocessing.transformer import CardioTransformer

# 🔹 Бір адамның дерегі
new_data = pd.DataFrame([{
    'age': 80,
    'gender': 2,
    'height': 189,
    'weight': 78.0,
    'ap_hi': 160,
    'ap_lo': 100,
    'cholesterol': 3,
    'gluc': 3,
    'smoke': 1,
    'alco': 1,
    'active': 1
}])

# 🔹 Деректерді жүктеу
full_data = pd.read_csv('cardio_train.csv', sep=';')

# 🔹 Ерекшеліктер мен мақсат айнымалыларын бөліп алу
X = full_data.drop(columns=['id', 'cardio'])
y = full_data['cardio']

# 🔹 Трансформация
transformer = CardioTransformer()
X_transformed = transformer.fit_transform(X)
y_aligned = y.loc[X_transformed.index]

X_new = transformer.transform(new_data)

# 🔹 RandomForest моделін қолдану
model = RandomForestModel(n_estimators=100, max_depth=5)
model.fit(X_transformed, y_aligned)

# 🔹 Болжау
prediction = model.predict(X_new)[0]
probas = model.predict_proba(X_new)[0]  # Бір қатар үшін ықтималдықтарды аламыз

# 🔹 Қандай кластармен жұмыс істеп тұрғанын көру
classes = model.model.classes_

# 🔹 Нәтиже шығару
print("🔍 Жеке адам үшін жүрек-қан тамыр ауруларының болу ықтималдығы:")
print(f"Нәтиже: {'✅ Иә, қауіп бар' if prediction == 1 else '🟢 Жоқ, қауіп жоқ'}")

# 🔹 Процентпен шығару (кластарды тексеру арқылы)
if isinstance(probas, (list, np.ndarray)):  # Егер probas тізім болса, дұрыс шығару
    print(f"Процентпен: Қауіп — {probas[0]*100:.2f}% (жоқ), {probas[1]*100:.2f}% (бар)")
else:
    # Егер тек бір мән болса
    print(f"Процентпен: Қауіп — {probas*100:.2f}% (бар) немесе {100 - probas*100:.2f}% (жоқ)")
