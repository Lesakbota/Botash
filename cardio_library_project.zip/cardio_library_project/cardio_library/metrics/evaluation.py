from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score

def evaluate_model(y_true, y_pred, y_proba):
    return {
        "accuracy": accuracy_score(y_true, y_pred),
        "precision": precision_score(y_true, y_pred),
        "recall": recall_score(y_true, y_pred),
        "f1_score": f1_score(y_true, y_pred),
        "roc_auc": roc_auc_score(y_true, y_proba)
    }

# cardio_library/metrics/evaluation.py

import matplotlib.pyplot as plt
from sklearn.metrics import ConfusionMatrixDisplay, confusion_matrix

def plot_confusion(y_true, y_pred, labels=None):
    """
    Қателер матрицасын салатын функция
    """
    cm = confusion_matrix(y_true, y_pred)
    disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=labels)
    disp.plot(cmap=plt.cm.Blues)
    plt.title("Қателер матрицасы")
    plt.show()

from sklearn.metrics import roc_curve, auc

def plot_roc_curve(y_true, y_probs):
    """
    ROC қисығын салу
    """
    fpr, tpr, _ = roc_curve(y_true, y_probs)
    roc_auc = auc(fpr, tpr)

    plt.figure()
    plt.plot(fpr, tpr, color='darkorange', lw=2, label=f'ROC-кривая (AUC = {roc_auc:.2f})')
    plt.plot([0, 1], [0, 1], color='navy', lw=2, linestyle='--')
    plt.xlim([0.0, 1.0])
    plt.ylim([0.0, 1.05])
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title('ROC-кривая')
    plt.legend(loc='lower right')
    plt.show()
def plot_confusion_matrices(y_true, model_preds, model_names, labels=None):
    """
    Бірнеше модельдің қателік матрицасын қатар көрсету
    """
    n_models = len(model_preds)
    fig, axes = plt.subplots(1, n_models, figsize=(6 * n_models, 5))

    for i, (pred, name) in enumerate(zip(model_preds, model_names)):
        cm = confusion_matrix(y_true, pred)
        disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=labels)
        disp.plot(ax=axes[i], cmap=plt.cm.Blues, values_format='d')
        axes[i].set_title(f"{name} - Қателік матрицасы")

    plt.tight_layout()
    plt.show()


def plot_roc_curves(y_true, model_probs, model_names):
    """
    Бірнеше модельдің ROC қисығын бір графикте салу
    """
    plt.figure(figsize=(8, 6))

    for probs, name in zip(model_probs, model_names):
        fpr, tpr, _ = roc_curve(y_true, probs)
        roc_auc = auc(fpr, tpr)
        plt.plot(fpr, tpr, lw=2, label=f'{name} (AUC = {roc_auc:.2f})')

    plt.plot([0, 1], [0, 1], linestyle='--', color='gray')
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title('ROC қисықтары')
    plt.legend(loc='lower right')
    plt.grid()
    plt.tight_layout()
    plt.show()


import matplotlib.pyplot as plt
from sklearn.metrics import roc_curve, auc


def plot_multiple_roc_curves(y_test, model_probas: dict):
    """
    Бір графикке бірнеше ROC қисығын салу

    Параметрлер:
    - y_test: нақты мәндер
    - model_probas: {"Модель аты": y_proba массиві}
    """
    plt.figure(figsize=(8, 6))

    for name, y_proba in model_probas.items():
        fpr, tpr, _ = roc_curve(y_test, y_proba)
        roc_auc = auc(fpr, tpr)
        plt.plot(fpr, tpr, lw=2, label=f"{name} (AUC = {roc_auc:.2f})")

    plt.plot([0, 1], [0, 1], 'k--', label='Кездейсоқ')
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title('📈 Барлық модельдердің ROC қисығы')
    plt.legend(loc='lower right')
    plt.grid(True)
    plt.tight_layout()
    plt.show()
