import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler

class CardioTransformer:
    def __init__(self):
        self.scaler = StandardScaler()
        self.numeric_cols = ['age', 'height', 'weight', 'ap_hi', 'ap_lo']

    def fit(self, X: pd.DataFrame):
        X_clean = self._clean_data(X.copy())
        self.scaler.fit(X_clean[self.numeric_cols])

    def transform(self, X: pd.DataFrame):
        X_clean = self._clean_data(X.copy())
        X_clean[self.numeric_cols] = self.scaler.transform(X_clean[self.numeric_cols])
        X_transformed = X_clean.drop(columns=["cardio"])
        y = X_clean["cardio"]
        return X_transformed, y

    def fit_transform(self, X: pd.DataFrame):
        X_clean = self._clean_data(X.copy())
        self.scaler.fit(X_clean[self.numeric_cols])
        X_clean[self.numeric_cols] = self.scaler.transform(X_clean[self.numeric_cols])
        X_transformed = X_clean.drop(columns=["cardio"])
        y = X_clean["cardio"]
        return X_transformed, y

    def _clean_data(self, X: pd.DataFrame):
        X['age'] = (X['age'] / 365).astype(int)
        X = X[(X['ap_hi'] > 40) & (X['ap_hi'] < 250)]
        X = X[(X['ap_lo'] > 30) & (X['ap_lo'] < 200)]
        X = X[X['ap_hi'] >= X['ap_lo']]
        return X.reset_index(drop=True)
