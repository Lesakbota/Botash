import numpy as np
from collections import Counter
from cardio_library.models.base_model import BaseModel

class LogisticModel(BaseModel):
    def __init__(self, learning_rate=0.01, n_iter=1000, reg_lambda=0.01, class_weight=None):
        self.learning_rate = learning_rate
        self.n_iter = n_iter
        self.reg_lambda = reg_lambda
        self.class_weight = class_weight  # ✅ class_weight параметрі
        self.weights = None
        self.bias = 0

    def get_params(self, deep=True):
        return {
            "learning_rate": self.learning_rate,
            "n_iter": self.n_iter,
            "reg_lambda": self.reg_lambda,
            "class_weight": self.class_weight  # ✅ параметрлерге қосу
        }

    def set_params(self, **params):
        for param, value in params.items():
            setattr(self, param, value)
        return self

    def sigmoid(self, z):
        z = np.array(z)
        z = np.clip(z, -250, 250)
        return 1 / (1 + np.exp(-z))

    def fit(self, X, y):
        n_samples, n_features = X.shape
        self.weights = np.zeros(n_features)

        # ✅ Салмақтарды орнату
        if self.class_weight == 'balanced':
            counter = Counter(y)
            total = len(y)
            weights = {cls: total / (len(counter) * count) for cls, count in counter.items()}
            sample_weights = np.array([weights[label] for label in y])
        else:
            sample_weights = np.ones(len(y))

        for _ in range(self.n_iter):
            linear_model = np.dot(X, self.weights) + self.bias
            y_predicted = self.sigmoid(linear_model)

            # ✅ Салмақталған градиенттер
            error = y_predicted - y
            dw = (1 / n_samples) * np.dot(X.T, sample_weights * error) + self.reg_lambda * self.weights
            db = (1 / n_samples) * np.sum(sample_weights * error)

            self.weights -= self.learning_rate * dw
            self.bias -= self.learning_rate * db

    def predict_proba(self, X):
        linear_model = np.dot(X, self.weights) + self.bias
        return self.sigmoid(linear_model)

    def predict(self, X):
        proba = self.predict_proba(X)
        return (proba >= 0.5).astype(int)
