# cardio_library/models/decision_tree_model.py
from sklearn.tree import DecisionTreeClassifier
from cardio_library.models.base_model import BaseModel

class DecisionTreeModel(BaseModel):
    def __init__(self, max_depth=None, min_samples_split=2, random_state=42):
        self.model = DecisionTreeClassifier(
            max_depth=max_depth,
            min_samples_split=min_samples_split,
            random_state=random_state
        )

    def fit(self, X, y):
        self.model.fit(X, y)

    def predict(self, X):
        return self.model.predict(X)

    def predict_proba(self, X):
        return self.model.predict_proba(X)[:, 1]

    def get_params(self, deep=True):
        return self.model.get_params(deep=deep)

    def set_params(self, **params):
        self.model.set_params(**params)
        return self
