# cardio_library/models/logistic_model.py

import numpy as np
from .base_model import BaseModel

class LogisticModel(BaseModel):
    def __init__(self, learning_rate=0.01, n_iter=1000, reg_lambda=0.01):
        self.learning_rate = learning_rate
        self.n_iter = n_iter
        self.reg_lambda = reg_lambda
        self.weights = None
        self.bias = 0

    def sigmoid(self, z):
        z = np.array(z)  # Кепілдік, numpy массив
        z = np.clip(z, -250, 250)  # 500 орнына 250 қолдан, қауіпсіз
        return 1 / (1 + np.exp(-z))



    def fit(self, X, y):
        n_samples, n_features = X.shape
        self.weights = np.zeros(n_features)

        for _ in range(self.n_iter):
            linear_model = np.dot(X, self.weights) + self.bias
            y_predicted = self.sigmoid(linear_model)

            # Градиенттер
            dw = (1 / n_samples) * np.dot(X.T, (y_predicted - y)) + self.reg_lambda * self.weights
            db = (1 / n_samples) * np.sum(y_predicted - y)

            # Параметрлерді жаңарту
            self.weights -= self.learning_rate * dw
            self.bias -= self.learning_rate * db

    def predict_proba(self, X):
        linear_model = np.dot(X, self.weights) + self.bias
        return self.sigmoid(linear_model)

    def predict(self, X):
        proba = self.predict_proba(X)
        return (proba >= 0.5).astype(int)
