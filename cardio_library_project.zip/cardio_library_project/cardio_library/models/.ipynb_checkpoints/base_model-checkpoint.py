# cardio_library/models/base_model.py

from abc import ABC, abstractmethod

class BaseModel(ABC):
    @abstractmethod
    def fit(self, X, y):
        """Модельді үйрету"""
        pass

    @abstractmethod
    def predict(self, X):
        """Болжам жасау"""
        pass

    @abstractmethod
    def predict_proba(self, X):
        """Сыныпқа жату ықтималдығын есептеу"""
        pass
