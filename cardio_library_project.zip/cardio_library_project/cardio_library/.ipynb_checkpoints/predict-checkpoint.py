import pandas as pd
from cardio_library.utils.save_load import load_model, load_transformer

# 🔹 Модель мен трансформерді жүктеу
model = load_model("cardio_library/models/logistic_model.pkl")
transformer = load_transformer("cardio_library/preprocessing/transformer.pkl")

# 🔹 Жаңа дерек (мысал үшін)
new_data = pd.read_csv("new_cardio_data.csv", sep=";")

# 🔹 Алдын ала өңдеу
X_new = transformer.transform(new_data)

# 🔹 Болжам жасау
predictions = model.predict(X_new)

# 🔹 Нәтижені шығару
print("Болжам нәтижелері:", predictions)
