import pandas as pd  # Деректерді өңдеу үшін pandas кітапханасын қосу
from sklearn.model_selection import train_test_split  # Мәліметтерді train/test деп бөлу
from sklearn.linear_model import LinearRegression  # Сызықтық регрессия моделін қосу
import pickle  # Модельді файлға сақтау үшін

# 1. CSV файлын оқу (үй бағалары туралы деректер)
df = pd.read_csv(r'C:\Users\14ken\house_price_forecast\house_data.csv')
# Қате жолдарды алып тастау
df = df[df['yr_built'] >= 1900]

# 2. Қажетті бағандарды таңдау
columns = ['bedrooms', 'bathrooms', 'floors', 'yr_built', 'price']
df = df[columns]

# 3. Тәуелсіз айнымалылар (фичалар) мен тәуелді айнымалыны (бағаны) бөлу
X = df.iloc[:, 0:4]  # Тәуелсіз айнымалылар (фичалар): bedrooms, bathrooms, floors, yr_built
y = df.iloc[:, 4:]   #  Тәуелді айнымалы (баға): price

# 4. Мәліметтерді оқыту (train) және тест (test) бөліктеріне бөлу
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25)

# 5. Сызықтық регрессия моделін құру және оқыту
lr = LinearRegression()
lr.fit(X_train, y_train)

# 6. Модельді файлға сақтау (кейін Flask қолданбасында пайдалану үшін)
pickle.dump(lr, open('model.pkl', 'wb'))


