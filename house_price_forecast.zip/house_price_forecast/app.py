from flask import Flask, render_template, request  # Flask модулін, HTML көрсету және форма мәліметін алу үшін қосу
import numpy as np  # Мәліметтермен жұмыс істеу үшін NumPy кітапханасы
import pickle  # Оқытылған модельді жүктеу үшін

app = Flask(__name__)  # Flask қосымшасын бастау

# Сақталған модельді жүктеу
model = pickle.load(open('model.pkl', 'rb'))

# Басты бет — форма көрсетіледі
@app.route('/')
def index():
    return render_template('index.html')

# Пайдаланушы жіберген мәліметтер арқылы бағаны болжау
@app.route('/predict', methods=['POST'])
def predict():
    # Формадан мәндерді алу
    val1 = request.form['bedrooms']
    val2 = request.form['bathrooms']
    val3 = request.form['floors']
    val4 = request.form['yr_built']

    # Мәндерді float түрінде массивке айналдыру
    arr = np.array([val1, val2, val3, val4], dtype=np.float64)

    # Модель арқылы баға болжау
    pred = model.predict([arr])

    # Болжанған нәтижені HTML бетіне жіберу
    return render_template('index.html', data=int(pred[0][0]))

# Қосымшаны іске қосу
if __name__ == '__main__':
    app.run(debug=True)
